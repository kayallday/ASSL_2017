# Running Remindify
# To run remindify you will need to install Python & Flask
#
# WINDOWS:
# If you are using Windows you can install these user command prompt and whatever package manager you wish
# ( I recommend chocolately )
#
#
# MAC:
# If you are using a Mac you can install these using terminal and whatever package manger you wish
#
#
# to run the app
# Run python remember.py from inside the project folder
# The app will be running on http://127.0.0.1:5000/
# Open this address in your browser
# 
